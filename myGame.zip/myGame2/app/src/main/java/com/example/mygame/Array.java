package com.example.mygame;

public class Array {
final int[] images1 = {
        R.drawable.zero,
        R.drawable.one,
        R.drawable.two,
        R.drawable.three,
        R.drawable.four,
        R.drawable.five,
        R.drawable.six,
        R.drawable.seven,
        R.drawable.eight,
        R.drawable.nine,

};


final int[] texts1 = {
       R.string.text_level1,
        R.string.text_level2,
        R.string.text_level3,
        R.string.text_level4,
        R.string.text_level5,
        R.string.text_level6,
        R.string.text_level7,
        R.string.text_level8,
        R.string.text_level9,
        R.string.text_level10,


    };

    final int[] images2 = {
            R.drawable.onef,
            R.drawable.twof,
            R.drawable.threes,
            R.drawable.nines,
            R.drawable.fours,
            R.drawable.fives,
            R.drawable.sixs,
            R.drawable.sevens,
            R.drawable.eights,
            R.drawable.tens,
            R.drawable.eleven,
            R.drawable.twelw,
            R.drawable.threet,
            R.drawable.fourteen,
            R.drawable.fifteen,
            R.drawable.sixsteen,
            R.drawable.seventeen,
            R.drawable.eighteen,
            R.drawable.nineteen,
            R.drawable.twenty,
            R.drawable.twentyone,

    };


    final int[] texts2 = {
            R.string.text15_level15,
            R.string.text14_level14,
            R.string.text18_level18,
            R.string.text17_level17,
            R.string.text19_level19,
            R.string.text20_level20,
            R.string.text16_level16,
            R.string.text1_level1,
            R.string.text2_level2,
            R.string.text13_level13,
            R.string.text21_level21,
            R.string.text9_level9,
            R.string.text8_level8,
            R.string.text7_level7,
            R.string.text3_level3,
            R.string.text6_level6,
            R.string.text4_level4,
            R.string.text5_level5,
            R.string.text11_level11,
            R.string.text12_level12,
            R.string.text10_level10,

    };
    final int[] images3 = {
            R.drawable.mercury,
            R.drawable.venera,
            R.drawable.earth,
            R.drawable.mars,
            R.drawable.ypiter,
            R.drawable.saturn,
            R.drawable.uran,


    };


    final int[] texts3 = {
            R.string.Levv1,
            R.string.Levv2,
            R.string.Levv3,
            R.string.Levv4,
            R.string.Levv5,
            R.string.Levv6,
            R.string.Levv7,

    };
    final int[] images4 = {
            R.drawable.neptun,
            R.drawable.uran,
            R.drawable.saturn,
            R.drawable.ypiter,
            R.drawable.mars,
            R.drawable.earth,
            R.drawable.venera,
            R.drawable.mercury,








    };


    final int[] texts4 = {
            R.string.Levv8,
            R.string.Levv7,
            R.string.Levv6,
            R.string.Levv5,
            R.string.Levv4,
            R.string.Levv3,
            R.string.Levv2,
            R.string.Levv1,








    };
    final int[] images5 = {
            R.drawable.jas,
            R.drawable.okun,
            R.drawable.karas,
            R.drawable.juka,
            R.drawable.tunec,









    };


    final int[] texts5 = {
            R.string.Levvv1,
            R.string.Levvv4,
            R.string.Levvv3,
            R.string.Levvv2,
            R.string.Levvv5,









    };

    final int[] images6 = {
            R.drawable.zero,
            R.drawable.one,
            R.drawable.two,
            R.drawable.three,
            R.drawable.four,
            R.drawable.five,
            R.drawable.six,
            R.drawable.seven,
            R.drawable.eight,
            R.drawable.nine,

    };


    final int[] texts6 = {
            R.string.text_level1,
            R.string.text_level2,
            R.string.text_level3,
            R.string.text_level4,
            R.string.text_level5,
            R.string.text_level6,
            R.string.text_level7,
            R.string.text_level8,
            R.string.text_level9,
            R.string.text_level10,


    };
    final int[] strong = {
      1, 0, 1, 0, 1, 0, 1, 0, 1, 0
    };


    final int[] images7 = {
            R.drawable.pes,
            R.drawable.bih,
            R.drawable.tre,
            R.drawable.el,
            R.drawable.si,






    };


    final int[] texts7 = {
            R.string.Lev1,
            R.string.Lev2,
            R.string.Lev3,
            R.string.Lev4,
            R.string.Lev5,



    };
    final int[] images8 = {





            R.drawable.sims,
            R.drawable.vicecity,
            R.drawable.rdr,
            R.drawable.gta,
            R.drawable.call,
            R.drawable.gta,

    };


    final int[] texts8 = {
            R.string.Le6,
            R.string.Le5,
            R.string.Le4,
            R.string.Le3,
            R.string.Le2,
            R.string.Le1,










    };
    final int[] images9 = {
            R.drawable.aple,
            R.drawable.olt,
            R.drawable.kartoshka,
            R.drawable.key,
            R.drawable.gr,
            R.drawable.uy,


    };


    final int[] texts9 = {
            R.string.L1,
            R.string.L2,
            R.string.L3,
            R.string.L4,
            R.string.L5,
            R.string.L6,


    };
    final int[] strong1 = {
            1, 0, 1, 0, 1, 0
    };

    final int[] images10 = {
            R.drawable.jav,
            R.drawable.pas,
            R.drawable.c_1,
            R.drawable.del,
            R.drawable.py,
            R.drawable.c1,


    };


    final int[] texts10 = {
            R.string.k1,
            R.string.k2,
            R.string.k3,
            R.string.k4,
            R.string.k5,
            R.string.k6,



    };
    final int[] strong2 = {
            1, 0, 1, 0, 1, 0
    };



}

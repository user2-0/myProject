package com.example.mygame;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class Level19 extends AppCompatActivity {

    Dialog dialog;
    Dialog dialogEnd;
    public int numLeft;
    public int numRight;
    Array array = new Array();
    Random random = new Random();
    public int count = 0;

    @SuppressLint("ResourceAsColor")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.univer);
        TextView text_levels = findViewById(R.id.text_levels);
        text_levels.setText(R.string.level_29);
        final ImageView test_left = (ImageView)findViewById(R.id.test_left);
        test_left.setClipToOutline(true);
        final ImageView test_right = (ImageView)findViewById(R.id.test_right);
        test_right.setClipToOutline(true);
        final TextView testleft = findViewById(R.id.Text_left);

        final TextView testRight = findViewById(R.id.text_2);

        Window win = getWindow();
        win.setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);

        ImageView background = (ImageView)findViewById(R.id.background);
        background.setImageResource(R.drawable.kasmasas);

        dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.preview_dialog);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setCancelable(false);


        ImageView previewim = (ImageView)dialog.findViewById(R.id.imgpreview);
        previewim.setImageResource(R.drawable.na_ha);

        LinearLayout dialogfon = (LinearLayout)dialog.findViewById(R.id.dialogfon);
        dialogfon.setBackgroundResource(R.drawable.levelprewiev);

        TextView textdec = (TextView)dialog.findViewById(R.id.textdec);

        textdec.setText(R.string.level6);

        TextView buttonclose = (TextView)dialog.findViewById(R.id.buttonclose);
        buttonclose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent intent = new Intent(Level19.this, GameLevels.class);
                    startActivity(intent);finish();
                }catch (Exception e) {}
                dialog.dismiss();

            }
        });
        dialog.show();
        Button btncontiniu = (Button)dialog.findViewById(R.id.buttoncont);
        btncontiniu.setBackgroundResource(R.drawable.white_press);
        btncontiniu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });




        Button btnback = (Button)findViewById(R.id.button_back);
        btnback.setBackgroundResource(R.drawable.style_press);
        btnback.setTextColor(R.color.white);

        btnback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent intent = new Intent(Level19.this, GameLevels.class);
                    startActivity(intent);finish();
                }catch (Exception e) {}
            }
        });
        dialogEnd = new Dialog(this);
        dialogEnd.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialogEnd.setContentView(R.layout.dialogend);
        dialogEnd.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialogEnd.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        dialogEnd.setCancelable(false);

        LinearLayout dialogfonEnd = (LinearLayout)dialogEnd.findViewById(R.id.dialogfon);
        dialogfonEnd.setBackgroundResource(R.drawable.levelprewiev);

        TextView textdecend = (TextView)dialogEnd.findViewById(R.id.textdecend);

        textdecend.setText(R.string.levelend6);

        TextView buttonclose2 = (TextView)dialogEnd.findViewById(R.id.buttonclose);
        buttonclose2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent intent = new Intent(Level19.this, GameLevels.class);
                    startActivity(intent);finish();
                }catch (Exception e) {}
                dialogEnd.dismiss();

            }
        });

        Button btncontiniu2 = (Button)dialogEnd.findViewById(R.id.buttoncont);
        btncontiniu2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent intent = new Intent(Level19.this, Level20.class);
                    startActivity(intent);finish();
                }catch (Exception e) {

                }
                dialogEnd.dismiss();
            }
        });

        final int[] progress =  {
                R.id.point1, R.id.point2, R.id.point3, R.id.point4, R.id.point5,
                R.id.point6, R.id.point7, R.id.point8, R.id.point9, R.id.point10,
                R.id.point11, R.id.point12, R.id.point13, R.id.point14, R.id.point15,
                R.id.point16, R.id.point17, R.id.point18, R.id.point19, R.id.point20,
        };

        final Animation a = AnimationUtils.loadAnimation(Level19.this, R.anim.alpha);

        numLeft = random.nextInt(7);
        test_left.setImageResource(array.images3[numLeft]);
        testleft.setText(array.texts3[numLeft]);

        numRight = random.nextInt(7);
        while (numLeft == numRight) {
            numRight = random.nextInt(7);
        }
        test_right.setImageResource(array.images3[numRight]);
        testRight.setText(array.texts3[numRight]);

        test_left.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction()==MotionEvent.ACTION_DOWN) {
                    test_right.setEnabled(false);
                    if(numLeft>numRight) {
                        test_left.setImageResource(R.drawable.img_true);
                    }else {
                        test_left.setImageResource(R.drawable.img_false);
                    }
                }else if(event.getAction()==MotionEvent.ACTION_UP) {
                    if(numLeft>numRight) {
                        if(count<20) {
                            count = count+1;
                        }
                        for(int i = 0; i < 20; i++) {
                            TextView tv = findViewById(progress[i]);
                            tv.setBackgroundResource(R.drawable.style_points);
                        }
                        for(int i = 0; i<count; i++) {
                            TextView tv = findViewById(progress[i]);
                            tv.setBackgroundResource(R.drawable.style_points_green);
                        }
                    }else {
                        if(count>0) {
                            if(count == 1) {
                                count = 0;
                            }else {
                                count = count - 2;
                            }
                        }
                        for(int i = 0; i < 19; i++) {
                            TextView tv = findViewById(progress[i]);
                            tv.setBackgroundResource(R.drawable.style_points);
                        }
                        for(int i = 0; i<count; i++) {
                            TextView tv = findViewById(progress[i]);
                            tv.setBackgroundResource(R.drawable.style_points_green);
                        }
                    }
                    if (count == 20) {
                        SharedPreferences save = getSharedPreferences("Save", MODE_PRIVATE);
                        final int level = save.getInt("Level", 1);
                        if(level>6) {

                        }
                        else {
                            SharedPreferences.Editor editor = save.edit();
                            editor.putInt("Level", 7);
                            editor.commit();
                        }
                        dialogEnd.show();
                    }else {
                        numLeft = random.nextInt(7);
                        test_left.setImageResource(array.images3[numLeft]);
                        test_left.startAnimation(a);
                        testleft.setText(array.texts3[numLeft]);

                        numRight = random.nextInt(7);
                        while (numLeft == numRight) {
                            numRight = random.nextInt(7);
                        }
                        test_right.setImageResource(array.images3[numRight]);
                        test_right.startAnimation(a);
                        testRight.setText(array.texts3[numRight]);

                        test_right.setEnabled(true);
                    }
                }

                return true;
            }
        });


        test_right.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction()==MotionEvent.ACTION_DOWN) {
                    test_left.setEnabled(false);
                    if(numLeft<numRight) {
                        test_right.setImageResource(R.drawable.img_true);
                    }else {
                        test_right.setImageResource(R.drawable.img_false);
                    }
                }else if(event.getAction()==MotionEvent.ACTION_UP) {
                    if(numLeft<numRight) {
                        if(count<20) {
                            count = count+1;
                        }
                        for(int i = 0; i < 20; i++) {
                            TextView tv = findViewById(progress[i]);
                            tv.setBackgroundResource(R.drawable.style_points);
                        }
                        for(int i = 0; i<count; i++) {
                            TextView tv = findViewById(progress[i]);
                            tv.setBackgroundResource(R.drawable.style_points_green);
                        }
                    }else {
                        if(count>0) {
                            if(count == 1) {
                                count = 0;
                            }else {
                                count = count - 2;
                            }
                        }
                        for(int i = 0; i < 19; i++) {
                            TextView tv = findViewById(progress[i]);
                            tv.setBackgroundResource(R.drawable.style_points);
                        }
                        for(int i = 0; i<count; i++) {
                            TextView tv = findViewById(progress[i]);
                            tv.setBackgroundResource(R.drawable.style_points_green);
                        }
                    }
                    if (count == 20) {
                        SharedPreferences save = getSharedPreferences("Save", MODE_PRIVATE);
                        final int level = save.getInt("Level", 1);
                        if(level>6) {

                        }
                        else {
                            SharedPreferences.Editor editor = save.edit();
                            editor.putInt("Level", 7);
                            editor.commit();
                        }
                        dialogEnd.show();
                    }else {
                        numLeft = random.nextInt(7);
                        test_left.setImageResource(array.images3[numLeft]);
                        test_left.startAnimation(a);
                        testleft.setText(array.texts3[numLeft]);

                        numRight = random.nextInt(7);
                        while (numLeft == numRight) {
                            numRight = random.nextInt(7);
                        }
                        test_right.setImageResource(array.images3[numRight]);
                        test_right.startAnimation(a);
                        testRight.setText(array.texts3[numRight]);

                        test_left.setEnabled(true);
                    }
                }

                return true;
            }
        });
    }
    @Override
    public void onBackPressed() {
        try {
            Intent intent = new Intent(Level19.this, GameLevels.class);
            startActivity(intent);finish();
        }catch (Exception e) {}
    }

}
